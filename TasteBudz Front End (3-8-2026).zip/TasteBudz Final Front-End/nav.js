fetch('nav.html')
.then(res => res.text())
.then(data => {
let oldElem = document.querySelector("script#replace_with_navbar");
let newElem = document.createElement("div");
newElem.innerHTML = data;
oldElem.parentNode.replaceChild(newElem, oldElem);
})
.catch(err => console.error('Error loading navbar:', err));